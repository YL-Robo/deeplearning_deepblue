# 保存模型
state = {
    'net': net.state_dict(),
    'loss': train_loss,
    'epoch': epoch,
}
savedir = os.path.join('/change/to/your/path')
logger.info('Saving to {}..'.format(savedir))
torch.save(state, savedir +'/ckpt.pth')

# 加载模型
checkpoint = torch.load('change/to/your/path/ckpt.pth')
net.load_state_dict(checkpoint['net'], strict=False)
train_loss = checkpoint['loss']
start_epoch = checkpoint['epoch']