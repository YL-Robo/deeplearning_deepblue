# -*- coding: utf-8 -*-
import torch
# Create a tensor and set requires_grad=True to track computation with it
x = torch.ones(2, 2, requires_grad=True) # or use x.requires_grad_(True)
print(x.data)
print(x.grad)
print(x.grad_fn)  # we've created x ourselves
# Do an operation of x:
y = x + 2 
print(y)
# y was created as a result of an operation, so it has a grad_fn
print(y.grad_fn)
z = y * y 
out = z.mean()
print(z, out)
out.backward()
print(x.grad)
# y.retain_graph() x.grad.data.zero_()
