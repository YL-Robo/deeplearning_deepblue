self.Linear1=nn.Linear(30,40)
self.Linear1.weight.data.fill_(-0.1)


for name, param in model.named_parameters():
    if param.requires_grad:
        print(name, param.data)
        

for p in model.parameters():
    # p.requires_grad: bool
    # p.data: Tensor

for name, param in model.state_dict().items():
    print(name)
    # name: str
    # param: Tensor

for name, param in model.modules().items():
    print(name)
    # name: str
    # param: Tensor