from torch.nn.modules.module import Module
from functions.rroi_align import RRoiAlignFunction
import roialign
from torch.autograd import Function
from torch.autograd.function import once_differentiable
from torch.nn.modules.utils import _pair
import torch

import pdb

class _ROIAlign(Function):
    @staticmethod
    def forward(ctx, features, rois, pooled_height, pooled_width, spatial_scale):
        ctx.save_for_backward(rois)
        ctx.pooled_width = pooled_width
        ctx.pooled_height = pooled_height
        ctx.spatial_scale = spatial_scale
        ctx.feature_size = features.size()
        batch_size, num_channels, data_height, data_width = ctx.feature_size
        num_rois = rois.size(0)
        output = torch.zeros(num_rois, num_channels, ctx.pooled_height, ctx.pooled_width, dtype=features.dtype, requires_grad=True).cuda()
        #output = features.new(num_rois, num_channels, ctx.pooled_height, ctx.pooled_width).zero_().float()
        #output.requires_grad = True
        # ctx.argmax = features.new(num_rois, num_channels, ctx.pooled_height, ctx.pooled_width).zero_().int()
        ctx.idx_x = torch.zeros(num_rois, num_channels, ctx.pooled_height, ctx.pooled_width, dtype=features.dtype, requires_grad=True).cuda()
        ctx.idx_y = torch.zeros(num_rois, num_channels, ctx.pooled_height, ctx.pooled_width, dtype=features.dtype, requires_grad=True).cuda()
        ctx.rois = rois
        roialign.roi_align_forward(ctx.pooled_height, ctx.pooled_width, ctx.spatial_scale,
                                                 features, rois, output, ctx.idx_x, ctx.idx_y)

        return output

    @staticmethod
    @once_differentiable
    def backward(ctx, grad_output):
        assert(ctx.feature_size is not None and grad_output.is_cuda)
        batch_size, num_channels, data_height, data_width = ctx.feature_size
        grad_input = torch.zeros(batch_size, num_channels, data_height, data_width, dtype=grad_output.dtype, requires_grad=True).cuda()
        roialign.roi_align_backward(ctx.pooled_height, ctx.pooled_width, ctx.spatial_scale,
                                              grad_output, ctx.rois, grad_input, ctx.idx_x, ctx.idx_y)
        print(grad_input.shape)
        return grad_input, None, None, None, None


roi_align = _ROIAlign.apply


class _RRoiAlign(Module):
    def __init__(self, pooled_height, pooled_width, spatial_scale):
        super(_RRoiAlign, self).__init__()

        self.pooled_width = int(pooled_width)
        self.pooled_height = int(pooled_height)
        self.spatial_scale = float(spatial_scale)
    def forward(self, input, rois):
        return roi_align(input, rois, self.pooled_height, self.pooled_width, self.spatial_scale)

    def __repr__(self):
        tmpstr = self.__class__.__name__ + "("
        tmpstr += "output_size=" + str(self.output_size)
        tmpstr += ", spatial_scale=" + str(self.spatial_scale)
        tmpstr += ", sampling_ratio=" + str(self.sampling_ratio)
        tmpstr += ")"
        return tmpstr
