// Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
#pragma once
#include "vision.h"

// Interface for Python
int ROIAlign_forward(const int pooled_height, const int pooled_width, const float spatial_scale,
                            const at::Tensor& features, const at::Tensor& rois, at::Tensor& output,
                            const at::Tensor& idx_x, const at::Tensor& idx_y) {
return rroi_align_forward_cuda(pooled_height, pooled_width, spatial_scale, features, rois, output, idx_x,idx_y);
}

int ROIAlign_backward(const int pooled_height, const int pooled_width, const float spatial_scale,
                            const at::Tensor& top_grad, const at::Tensor& rois, at::Tensor& bottom_grad,
                            const at::Tensor& idx_x, const at::Tensor& idx_y) {
return rroi_align_backward_cuda(pooled_height, pooled_width, spatial_scale, top_grad, rois, bottom_grad, idx_x,idx_y);
}                 