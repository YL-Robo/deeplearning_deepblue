// Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
#pragma once
#include <torch/extension.h>


int rroi_align_forward_cuda(const int pooled_height, const int pooled_width, const float spatial_scale,
                            const at::Tensor& features, const at::Tensor& rois, at::Tensor& output,
                            const at::Tensor& idx_x, const at::Tensor& idx_y);

int rroi_align_backward_cuda(const int pooled_height, const int pooled_width, const float spatial_scale,
                            const at::Tensor& top_grad, const at::Tensor& rois, at::Tensor& bottom_grad,
                            const at::Tensor& idx_x, const at::Tensor& idx_y);

