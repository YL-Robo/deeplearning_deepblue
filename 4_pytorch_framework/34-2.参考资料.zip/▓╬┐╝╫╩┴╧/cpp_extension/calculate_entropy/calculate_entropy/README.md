cd src
nvcc -c -o calculate_entropy_kernel.cu.o calculate_entropy_kernel.cu -x cu -Xcompiler -fPIC -arch=sm_60
cd ../
python build.py