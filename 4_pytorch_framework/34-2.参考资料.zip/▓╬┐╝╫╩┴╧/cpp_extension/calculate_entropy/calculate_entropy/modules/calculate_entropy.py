from torch.nn.modules.module import Module
from ..functions.calculate_entropy import CalculateEntropyFunction
import torch.nn.init as init
from torch.autograd import Variable
import torch

class CalculateEntropyModule(Module):
    def __init__(self):
        super(CalculateEntropyModule, self).__init__()
        self.calentropy = CalculateEntropyFunction()
    def forward(self, input):
        num, channel, height, width = input.size()
        # output = Variable(torch.randn(num, 1, height, width)).cuda()
        # output.require_grad = False
        return self.calentropy(input)