int calculate_entropy(THCudaTensor * data, const int num, const int channel, const int height, int width, THCudaTensor* output);

