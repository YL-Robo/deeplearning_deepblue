#ifndef _TRIM_FIXED_POINT
#define _TRIM_FIXED_POINT

#ifdef __cplusplus
extern "C" {
#endif

int calculate_entropy_gpu(const float* input, const int num,
      const int channels, const int height, int width, float* output,
      cudaStream_t stream);

#ifdef __cplusplus
}
#endif

#endif
