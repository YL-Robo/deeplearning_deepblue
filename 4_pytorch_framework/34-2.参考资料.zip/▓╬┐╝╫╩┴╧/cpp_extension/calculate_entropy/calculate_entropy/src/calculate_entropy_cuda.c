#include <THC/THC.h>
#include <TH/TH.h>
#include <math.h>
#include <assert.h>
#include <stdio.h>

#include "calculate_entropy_kernel.h"


extern THCState *state;

int calculate_entropy(THCudaTensor * data, const int num,
	const int channels, const int height, int width, THCudaTensor* output) {
	float* data_in = THCudaTensor_data(state, data);
	float* output_data = THCudaTensor_data(state, output);
    cudaStream_t stream = THCState_getCurrentStream(state);
    calculate_entropy_gpu(
               data_in,
               num,
               channels,
               height,
               width,
               output_data,
               stream);
    return 1;
}
