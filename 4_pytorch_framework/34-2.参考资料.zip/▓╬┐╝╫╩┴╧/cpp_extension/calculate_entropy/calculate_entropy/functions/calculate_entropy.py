import torch
from torch.autograd import Function
from .._ext import calculate_entropy as C_wrapper
import pdb
import torch.nn.functional as F

class CalculateEntropyFunction(Function):
    def __init__(self,):
        None
    def forward(self, input):
        if not input.is_cuda:
            raise NotImplementedError
        else:
            self.num, self.channel, self.height, self.width = input.size()
            output = torch.Tensor(torch.randn(self.num, 1, self.height, self.width)).cuda()
            self.save_for_backward(input)
            C_wrapper.calculate_entropy(input, self.num, self.channel, self.height, self.width, output)
            return output
    def backward(self, output_grad):
        # input,  = torch.Tensor(torch.zeros(self.num, self.channel1, self.height, self.width)).cuda()
        # input_grad = input*0
        # print input_grad.size(), input_grad.type(), output_grad.type()
        input_grad = torch.Tensor(torch.zeros(self.num, self.channel, self.height, self.width)).cuda()
        return input_grad