import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Variable
from modules.calculate_entropy import CalculateEntropyModule
import time
import torch.nn.functional as F

class MyNetwork(nn.Module):
    def __init__(self):
        None
    def forward(self, input):
        return CalculateEntropyModule()(input)

net = MyNetwork()

input = Variable(torch.randn(1, 2, 4, 4)).cuda()
prob = F.softmax(input)
print input
time_start=time.time()
output = net.forward(prob)
time_end=time.time()
print output
print('gpu totally cost',time_end-time_start)