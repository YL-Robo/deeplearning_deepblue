class MyDataset(data.Dataset):
    def __init__(self, dataname, transform=None):
        # 初始化：数据位置、输入大小
    def __getitem__(self, index):
        # 提取一对数据
    def __len__(self):
        # 总共提取的个数
    def collate_fn(self, batch):
        # 包装成pytorch 网络输入
dataset = MyDataset()
dataloader = torch.utils.data.DataLoader(dataset, batch_size=8,\
                                        shuffle=False, num_workers=1)
for epoch in range(max_epoch):                                     
    for idx, (data, lebel) in enumerate(dataloader):
        ...